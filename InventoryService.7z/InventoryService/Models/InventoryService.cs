﻿namespace InventoryService.Models;

public record InventoryItem(int ProductId, int Quantity, string Location);
