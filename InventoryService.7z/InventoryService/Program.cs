using System.Net.Http.Json;
using InventoryService.Models;

var builder = WebApplication.CreateBuilder(args);

var productServiceUrl =
    Environment.GetEnvironmentVariable("PRODUCT_SERVICE_URL")
    ?? "http://localhost:5001";

builder.Services.AddHttpClient("products", client =>
{
    client.BaseAddress = new Uri(productServiceUrl);
});

var app = builder.Build();

app.MapGet("/", () => "InventoryService OK");

app.MapGet("/inventory/{id:int}", async (int id, IHttpClientFactory factory) =>
{
    Console.WriteLine($"[InventoryService] GET /inventory/{id}");

    var client = factory.CreateClient("products");
    var response = await client.GetAsync($"/products/{id}");

    if (response.IsSuccessStatusCode)
    {
        var product = await response.Content.ReadFromJsonAsync<object>();
        var inventory = new InventoryItem(id, 42, "Main Warehouse");

        Console.WriteLine("[InventoryService] ProductService returned 200");
        return Results.Ok(new { product, inventory });
    }

    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
    {
        Console.WriteLine("[InventoryService] 404 from ProductService");
        return Results.NotFound(new { message = "Product not found in catalog" });
    }

    return Results.StatusCode((int)response.StatusCode);
});

app.Logger.LogInformation(
    "InventoryService listening on http://localhost:5002 (product-service: {url})",
    productServiceUrl
);

app.Run("http://localhost:5002");
