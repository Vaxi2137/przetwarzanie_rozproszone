﻿namespace ProductService.Models
{
    public record Product(int Id, string Name, decimal Price);
}
