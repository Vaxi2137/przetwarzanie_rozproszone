using ProductService.Data;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "ProductService OK");

app.MapGet("/products/{id:int}", (int id) =>
{
    Console.WriteLine($"[ProductService] GET /products/{id}");

    if (Seed.Products.TryGetValue(id, out var product))
    {
        Console.WriteLine($"[ProductService] Found product {id}");
        return Results.Ok(product);
    }

    Console.WriteLine($"[ProductService] Not found {id}");
    return Results.NotFound(new { message = "Product not found" });
});

app.Logger.LogInformation("ProductService listening on http://localhost:5001");
app.Run("http://localhost:5001");
