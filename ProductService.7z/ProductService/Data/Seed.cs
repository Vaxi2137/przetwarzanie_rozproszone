﻿using ProductService.Models;

namespace ProductService.Data
{
    public static class Seed
    {
        public static readonly Dictionary<int, Product> Products = new()
        {
            { 1, new Product(1, "Klawiatura", 129.99m) },
            { 2, new Product(2, "Mysz", 79.50m) },
            { 3, new Product(3, "Monitor 24\"", 599.00m) },
        };
    }
}
